KOVA - Native Windows Gaming Utility (manual presets edition)
================================================================
Run Kova.exe on Windows 10/11 x64. No Electron, browser or runtime installer.

NEW: MANUAL PRESETS
- The app starts with its DEFAULT settings each time. It does NOT read or
  write config.json and never auto-loads a saved profile.
- On Settings, choose one of four preset slots, type an optional name,
  and click Save Preset. Saved presets persist across launches.
- Click Load Preset to apply that slot ON DEMAND.
- Click Delete to delete one saved profile (requires confirmation).
- Reset Session resets Kova's in-app settings but does not undo any Windows
  resolution mode already confirmed in the Display tab.
- Profiles are stored at %LOCALAPPDATA%\Kova\Preset_1.kova etc.
- If the preset uses an imported PNG crosshair, an accompanying
  Preset_1.png etc is saved and loaded with it.
- Unsaved imported crosshair PNGs are NOT auto-loaded on the next launch.
- An already-installed older Kova/hud config.json is intentionally ignored.

DISPLAY SAFETY
- Display tab offers per-game resolution suggestions, selectable game
  categories, and typed custom width/height fields.
- Saving a Kova preset remembers which resolution was SELECTED, but loading
  that profile does not change your monitor's display mode.
- Click Apply Resolution manually and confirm within 15 seconds.
- Confirmed mode changes last for the Windows session; the app does NOT
  write the chosen mode to Windows' persistent display registry settings.
- Unsupported custom display modes are rejected by Windows/GPU drivers.

OTHER FEATURES
- Transparent PNG crosshair importer; 12 built-in shapes; crosshair overlay.
- F1 global overlay toggle; minimize to taskbar or optional tray.
- Competitive game resolution suggestions are not popularity rankings and
  are not guaranteed to be accepted by Windows or by a particular game.
- Desktop colour matrix and hardware gamma ramps depend on Windows display
  support. No injection or anti-cheat bypass. HDR/exclusive-fullscreen may
  not allow the adjustments. Colour effects restore on normal app exit.

DEVELOPMENT / VERIFICATION
- Freestanding native Win32/GDI+ C++, x64, with an embedded Windows icon.
- Cross-compiled using clang-cl and lld-link from Linux. PE x64 import table
  verified (SetBkMode and SetTextColor correctly imported from GDI32.DLL).
- This sandbox cannot execute and GUI-test a Windows app; runtime testing on
  a Windows computer is still recommended.

Build (from this source directory with clang-cl/lld-link available):
  clang-cl --target=x86_64-pc-windows-msvc /O2 /GS- /GR- /EHs- /Zl /c /Fo:Kova.obj Kova.cpp
  lld-link /out:Kova.exe /machine:x64 /subsystem:windows /entry:WinMainCRTStartup /nodefaultlib /opt:ref /opt:icf /incremental:no Kova.obj Kova.res kernel32.lib user32.lib gdi32.lib gdiplus.lib shell32.lib ole32.lib comdlg32.lib magnification.lib
